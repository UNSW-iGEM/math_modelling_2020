# math_modelling_2020
Mathematical modelling for iGEM

## Rendering flow chart of reaction

run `python3 render.py model.py | neato -T png -o model.png`
